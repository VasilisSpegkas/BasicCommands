
/*
Write a Java program and compute the sum of the digits of an integer.
Input Data:
Input an integer: 25

Expected Output
The sum of the digits is: 7
 */
import java.util.Scanner;

public class Exercise_033_Sum_of_digits_of_a_number {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);
		System.out.println("Please enter the number: ");
		long number = input.nextLong();
		System.out.println("The sum is: " + sumDigits(number));
	}		
		public static int sumDigits(long number) {
			int sum = 0;
			while (number != 0) {
				sum += number % 10;
				System.out.println(sum);
				number /= 10;
				System.out.println(number);
			}
			return sum;
		}
		
	}