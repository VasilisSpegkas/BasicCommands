
//Write a Java program to count the letters, spaces, numbers and
//other characters of an input string. 

//Expected Output
//The string is :  Aa kiu, I swd skieo 236587. GH kiu: sieo?? 25.33
//letter: 23                                               
//space: 9                                                 
//number: 10                                               
//other: 6

import java.util.Scanner;

public class Exercise_038_Count_letters_spaces_numbers_of_a_String {

	public static void main(String[] args) {
		
		String test = "Aa kiu, I swd skieo 236587. GH kiu: sieo?? 25.33";
		count(test);
		}
		
		//We create a method called "count" with an argument variable
		//"type String" named "x"
		public static void count(String x) {
			
			//The method toCharArray() returns an Array of chars
			//after converting a String into sequence of characters.
			char[] ch = x.toCharArray();
			int letter = 0;
			int space = 0;
			int num = 0;
			int other = 0;
			
			for (int i=0; i < x.length(); i++) {
				//We use methods from the default "Character" class
				
				//.isLetter checks for a Letter character
				if (Character.isLetter(ch[i])) {
					letter ++ ;
				}
				//.isDigit means and Decimal digit number
				else if (Character.isDigit(ch[i])) {
					num ++ ;
				}
				//.isWhitespace means any Unicode whitespace character
				//We can also use
				//else if (ch[i] == ' ') { }
				else if (Character.isWhitespace(ch[i])) {
					space ++ ;
				}
				else{
					other ++ ;
				}
			}
			System.out.println("The string is : Aa kiu, I swd skieo 236587. GH kiu: sieo?? 25.33");
			System.out.println("letter: " + letter);
			System.out.println("space: " + space);
			System.out.println("number: " + num);
			System.out.println("other: " + other);
	}
}