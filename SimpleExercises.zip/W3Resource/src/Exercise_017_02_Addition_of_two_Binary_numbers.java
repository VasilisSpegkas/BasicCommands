

public class Exercise_017_02_Addition_of_two_Binary_numbers {
	//Using parsing method to add binary numbers.
		public String addBinary(){
			// The two input Strings, containing the binary representation of the two values:
			String input0 = "10";
			String input1 = "11";

			//In the "parseInt" method the first argument is a string
			//represantation of our number and the second argument
			//represents the radix we want to use. We use radix 2 because it's binary.    
			int number0 = Integer.parseInt(input0, 2);
			int number1 = Integer.parseInt(input1, 2);

			int sum = number0 + number1;
			
			//The toBinaryString returns the value of "sum" on binary form
			System.out.println(sum);
			return Integer.toBinaryString(sum);
			
			}
}
