
//Write a Java program that takes two numbers as input and
//display the product of those numbers.
import java.util.Scanner;

public class Exercise_005_Input_number_and_Multiply {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Input first number: ");
		int number1 = input.nextInt();
		
		System.out.println("Input second number to multiply with: ");
		int number2 = input.nextInt();
		
		System.out.println("The result is: " + number1 * number2 );
	}

}
