/*Write a Java program to print the odd numbers from 1 to 99. 
 * Prints one number per line. 
 * 
Sample Output:
1                                                                      
3                                                                      
5                                                                      
7                                                                      
9                                                                      
11                                                                     
....                                                                     
                                                                    
91                                                                     
93                                                                     
95                                                                     
97                                                                     
99 */


public class Exercise_048_Diplay_Odd_numbers_inside_a_specific_range {

	public static void main(String[] args) {
		
		//Range<Integer> myRange = Range.between(0, 100);
		//while (myRange.contains(num)){
		//}
		for (int i = 1; i < 100; i++) {
			if (i % 2 != 0) {
				System.out.println(i);
			}
		}
	}

}
