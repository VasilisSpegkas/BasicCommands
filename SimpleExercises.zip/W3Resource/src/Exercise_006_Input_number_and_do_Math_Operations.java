
//Write a Java program to print the sum (addition),
//multiply, subtract, divide and remainder of two numbers.
import java.util.Scanner;

public class Exercise_006_Input_number_and_do_Math_Operations {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.println("Enter first number");
		int number1 = input.nextInt();
		System.out.println("Enter second number");
		int number2 = input.nextInt(); 
		
		System.out.println(number1 + number2);
		System.out.println(number1 - number2);
		System.out.println(number1 * number2);
		System.out.println(number1 / number2);
		System.out.println(number1 % number2);
		
	}

}
