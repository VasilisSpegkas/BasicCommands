
//Write a Java program to reverse a string.
//Input Data:
//Input a string: The quick brown fox 

//Expected Output
//Reverse string: xof nworb kciuq ehT
import java.util.Scanner;

public class Exercise_037_Reverse_a_String {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the string to reverse");
		
		//The method toCharArray() returns an Array of chars
		//after converting a String into sequence of characters.
		//So the next line translates to:
		//Create a list of "type char" named "word" and add inside
		//it whatever is inside the "input" variable using the
		//"toCharArray" method.
		char[] word = input.nextLine().toCharArray();
		System.out.println("Reverse string: ");
		
		for (int i = word.length -1; i >= 0; i--) {
			System.out.print(word[i]);
			}
	}

}
