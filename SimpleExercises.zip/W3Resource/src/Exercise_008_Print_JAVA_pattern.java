
//Write a Java program to display a JAVA pattern.
public class Exercise_008_Print_JAVA_pattern {

	public static void main(String[] args) {
		System.out.println("   J    a   v     v  a ");
		System.out.println("   J   a a   v   v  a a");
		System.out.println("J  J  aaaaa   V V  aaaaa");
		System.out.println(" JJ  a     a   V  a     a");
	}

}
