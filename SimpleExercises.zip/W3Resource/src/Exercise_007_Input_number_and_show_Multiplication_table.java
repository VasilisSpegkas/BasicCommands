
//Write a Java program that takes a number as input and prints 
//its multiplication table up to 10.
import java.util.Scanner;

public class Exercise_007_Input_number_and_show_Multiplication_table {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Please enter a number: ");
		int num = input.nextInt();
				
		for(int count=1; count<11; count++) {
			System.out.println(num + " x " + count + " = " + count * num);
		}
		
	}

}
