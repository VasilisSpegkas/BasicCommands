
//Write a Java program to swap two variables
import java.util.Scanner;

public class Exercise_015_Input_and_swap_variables_values {

	public static void main(String[] args) {
		
		String var1;
		String var2 = "New value";
		
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the value of your variable: ");
		var1 = input.nextLine();
		
		
		System.out.println("Variable with old value: '" + var1 + "' has been transformed to '" + (var1 = var2)+ "'");
		
		
	}

}
