
//Write a Java program to print 'Hello' 
//on screen and then print your name on a separate line.
public class Exercise_001_Hello_world {
	
	public static void main(String[] args) {
		
		System.out.println("Hello\nBill");
	}

}
