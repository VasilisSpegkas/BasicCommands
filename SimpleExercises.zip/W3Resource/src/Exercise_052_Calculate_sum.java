/*
Write a Java program to calculate the sum of two integers
and return true if the sum is equal to a third integer. 

Sample Output:
Input the first number : 5                                             
Input the second number: 10                                            
Input the third number : 15                                            
The result is: true
*/

import java.util.Scanner;

public class Exercise_052_Calculate_sum {

public static void main(String[] args)
		{		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Please enter the first number: ");
		int num1 = input.nextInt();
		
		System.out.println("Please enter the second number: ");
		int num2 = input.nextInt();
				
		System.out.println("Please enter the sum number you wish to check if equal: ");
		int num3 = input.nextInt();
				
		System.out.println("The result is: " + sumOfNumbers(num1,num2,num3));
		}
		public static boolean sumOfNumbers(int a, int b, int c) 
		{
			//If the condition is correct mathematically then it will
			//hold the value "True". Else it will hold the value "False"
			return (a + b == c);
		}
		
		//Another way
		//int sum = num1 + num2;
		
				/*if (num3 == sum) {
					System.out.println("The result is true!");
				}
				else {
					System.out.println("The result is false!");
				}*/
}


