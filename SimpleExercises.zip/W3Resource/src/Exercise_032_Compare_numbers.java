
/*Write a Java program to compare two numbers.

Input Data:
Input first integer: 25
Input second integer: 39

Expected Output
25 != 39                                                                          
25 < 39                                                                           
25 <= 3
*/
import java.util.Scanner;

public class Exercise_032_Compare_numbers {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter the first number: ");
		int a  = input.nextInt();
		System.out.println("Please enter the second number: ");
		int b = input.nextInt();
		
		//The "?" (question mark) is used like this
		/*
		 If (what is in here is true)
		 	doThis();
		 else
			doThat();
		Its syntax looks like this:
		(what is in here is true) ? doThis() : doThat();
		*/
		
		System.out.println("\n" + (a != b ? a + " != " + b : a + " == " + b));
		if(a != b) System.out.println(a < b ? a + " < " + b : b + " < " + a);
		System.out.println(a <= b ? a + " <= " + b : b + " <= " + a);
			
	}		
}
