
//Write a Java program to divide two numbers and print on the screen.
public class Exercise_003_Divide_numbers {

	public static void main(String[] args) {
		int a = 60;
		int b = 3;
		System.out.println(a/b);
	}

}
