
//Write a Java program to print a face. Find a way to
//print the double apostrophes.
public class Exercise_016_Print_a_face {

	public static void main(String[] args) {
		
		//To print a double apostrophe we use \"
		//For example to print "Hello" we type it like this
		System.out.println("\"Hello\"");
		//instead of just Hello
		System.out.println("Hello");
		
		//Another way is to use the ASCII code
		//(You can look up a symbol's ASCII code by
		//searching for an ASCII code table online)
		System.out.println((char)34+"Hello"+(char)34);
		
		System.out.println(" +\"\"\"\"\"+ ");
		System.out.println("[| o o |] ");
		System.out.println(" |  ^  | ");
		System.out.println(" | '-' |");
		System.out.println(" +-----+");
		
		
	} 

}
