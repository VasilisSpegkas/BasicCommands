
//Write a Java program to print the ascii value of a given 
//character.
//
//Expected Output
//The ASCII value of Z is :90

import java.util.Scanner;

public class Exercise_041_ASCII_value_of_a_character {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a single letter to convert to ascii: ");
		String letter = input.nextLine();
		int ascii = letter.charAt(0);
		System.out.println("The ASCII value of " + letter + " is :" + ascii );
		
	}
}
