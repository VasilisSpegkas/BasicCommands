
/*Write a Java program to accept a number and check the number is even or not. 
Prints 1 if the number is even or 0 if the number is odd.
Sample Output:

Input a number: 20                                                     
1
*/

import java.util.Scanner;
public class Exercise_049_Check_Odd_or_Even {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter number: ");
		int num = input.nextInt();
		
		if (num % 2 == 0) {
			System.out.println("Your number is even! " + 1);
			}
		else {
			System.out.println("Your number is odd! " + 0);
			}
		
	}

}
