/*
Write a Java program to convert a string to an integer in Java.
Sample Output:

Input a number(string): 25                                             
The integer value is: 25
*/

import java.util.Scanner;

public class Exercise_051_Convert__String_to_Integer {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter your string number: ");
		String wordString = input.nextLine();
		int wordInt = Integer.parseInt(wordString);
		System.out.println("Your String number has been converted to an Integer: " + wordString);
	}
}	
