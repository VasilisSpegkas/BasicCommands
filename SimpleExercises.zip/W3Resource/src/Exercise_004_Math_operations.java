
/*Write a Java program to print the result of the 
  following operations.
Test Data:
-5 + 8 * 6
(55+9) % 9 
20 + -3*5 / 8 
5 + 15 / 3 * 2 - 8 % 3 
*/
public class Exercise_004_Math_operations {

	public static void main(String[] args) {
		
		int w = -5 + 8*6;
		int x = (55+9) % 9;
		int y = 20 + -3*5 / 8;
		int z = 5 + 15/3*2 -8%3;
		
		System.out.print(w + "\n" + x + "\n" + y + "\n" + z);
	}

}
