//Write a Java program that accepts an integer (n) and 
//computes the value of n+nn+nnn.

//Sample Output:
//Input number: 5                                                        
//5 + 55  + 555

import java.util.Scanner;

public class Exercise_044_Input_integer_compute_specific_value {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a number: ");
		int num = input.nextInt();
		
		System.out.printf("%d + %d%d + %d%d%d\n", num, num, num, num, num, num);
		
		//Another solution
		//System.out.println(num + " + " + num + "" + num + " + " + num + "" + num + "" + num);
		
	}

}
