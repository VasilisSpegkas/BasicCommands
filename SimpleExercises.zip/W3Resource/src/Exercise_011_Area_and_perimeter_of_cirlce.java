
//Write a Java program to print the area(Pi*r^2) and perimeter(2*Pi*r) of a circle.

public class Exercise_011_Area_and_perimeter_of_cirlce {

	public static void main(String[] args) {
		
		double radius = 7.5;
		
		System.out.println("The perimeter of the circle is: " + 2 * Math.PI * radius);
		System.out.println("The area of the circle is: " + (radius*radius) * Math.PI );
		
	}

}
