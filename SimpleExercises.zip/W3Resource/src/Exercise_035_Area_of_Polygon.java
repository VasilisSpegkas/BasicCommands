/*
Write a Java program to compute the area of a polygon.
Area of a polygon = (n*s^2)/(4*tan(PI/n))
where n is n-sided polygon and s is the length of a side
Input Data:
Input the number of sides on the polygon: 7
Input the length of one of the sides: 6

Expected Output
The area is: 130.82084798405722
 */

import java.util.Scanner;

public class Exercise_035_Area_of_Polygon {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the number of the polygon's sides: ");
		int sides = input.nextInt();
		System.out.println("Enter the length of one of the sides: ");
		int len = input.nextInt();
		System.out.println("The area of the polygon is: " + polygonArea(sides,len));
	}
public static double polygonArea(int sides, int len) {
	return (sides*(len*len))/(4*Math.tan(Math.PI/sides)); 
	}

}
