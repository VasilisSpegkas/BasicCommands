
//Write a Java program to print the sum of two numbers.
public class Exercise_002_Sum_of_numbers {
	
	public static void main(String[] args) {
		
		System.out.println(74+36);
	}

}
