
/*
Write a Java program to compute the area of a hexagon.
Area of a hexagon = (6 * s^2)/(4*tan(PI/6))
where s is the length of a side
Input Data:
Input the length of a side of the hexagon: 6

Expected Output
The area of the hexagon is: 93.53074360871938
 */
import java.util.Scanner;

public class Exercise_034_Area_of_Hexagon {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the length of the hexagon's size: ");
		double len = input.nextDouble();
		System.out.println("The area of the hexagon is: " + hexagonArea(len));
	}	
public static double hexagonArea(double len) {
	return (6 * (len*len)/(4*Math.tan(Math.PI/6)));
		
		}
}
