
//Write a Java program that takes three numbers as input to calculate 
//and print the average of the numbers. 
import java.util.Scanner;

public class Exercise_012_Input_and_calculate_Average_of_numbers {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter first number");
		int number1 = input.nextInt();
		System.out.println("Please enter second number");
		int number2 = input.nextInt();
		System.out.println("Please enter third number");
		int number3 = input.nextInt();
		
		System.out.println("The average of your three numbers is: " + (number1 + number2 + number3) / 3);
		
		
		
		
	}

}
