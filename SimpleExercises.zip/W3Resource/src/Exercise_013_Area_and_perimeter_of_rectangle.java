
//Write a Java program to print the area and perimeter of a rectangle.
public class Exercise_013_Area_and_perimeter_of_rectangle {

	public static void main(String[] args) {
		
		double width = 5.5;
		double height = 8.5;
		
		System.out.println("The area of a rectangle is: " + width * height);
		System.out.println("The perimeter of a rectangle is: " + 2*(width + height));
	}

}
