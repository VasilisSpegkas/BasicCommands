

//Write a Java program to create and display unique three-digit number using 1, 2, 3, 4. 
//Also count how many three-digit numbers are there.
//
//Expected Output
//123                                                      
//124                                                      
//...                                            
//                                                   
//431                                                      
//432                                                      
//Total number of the three-digit-number is 24

public class Exercise_039_Three_Digit_number_problem {

	public static void main(String[] args) {
		
		//We create the "amount" variable and use it as a counter to store how many
		//times we printed a number.
		int amount = 0;
		for(int i = 1; i <= 4; i++) {
			for(int j = 1; j <= 4; j++) {
				//THIS IS WHERE IT GETS TRICKY.
				//For "j" to become "2" the value "k" needs to fail its condition one time. 
				//Basically the last "for loop" line checks itself and adds +1 to "k" until "k" 
				//is equal to 4 and fails its condition. Then so it will fall back to the second
				//"for loop" add +1 to "j" value and move again to the "k" value add +1 until it
				//becomes "3" and all the conditions inside the "if statement" are met. Then it can 
				//finally print the first number which is "123".
				for(int k = 1; k <=4; k++) {
					if( i != j && j!= k && i != k) {
						amount++;
						System.out.println(i + "" + j + "" + k);
						
					}
				}
			}
		}
		//Finally we print out our counter variable 
		System.out.println("Total number of the three-digit-numbers is: " + amount);
	}

}
