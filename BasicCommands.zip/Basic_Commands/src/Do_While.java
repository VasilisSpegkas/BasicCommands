import java.util.Scanner;

public class Do_While {

	public static void main(String[] args) {
		
		int t = 5;
		System.out.println(t *= 2);
		if (!(t>15)) {
			System.out.println("Success!");
		}
		
		
		Scanner scanner = new Scanner(System.in);
		
		//Will loop indefinately and ask the user for
		//a number until the user inputs number "5"
		int value = 0;
		do {
			System.out.println("Enter a number: ");
			value = scanner.nextInt();
		}
		while(value != 5);
		
		System.out.println("Got 5!");
	
	}

}
