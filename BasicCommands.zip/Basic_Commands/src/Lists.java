
public class Lists {

	public static void main(String[] args) {
		
		//We create an integer type array and call it "numbers"
		int[] numbers; //Most common way to declare an array
		int numbers01[]; //Not so common way but still correct
		int[] numbers02 = new int[10]; //Must enter the number of indexes the array will have
		int[] numbers03 = new int[] {1,2,3}; //Must enter the values(elements) we want to store inside the array
		
		
		//Assigning the array called "numbers"
		//enough memory to hold 3 integers
		numbers = new int[3];
		
		//Print out from array called "numbers"
		//index number 1. By default java assigns
		//values inside an array with the number 0.
		//Since we haven't assigned any numbers in 
		//our array java will print out the default
		//number 0
		System.out.println("Example 1");
		System.out.println(numbers[1]);
		
		//We assign each index a number and print them
		System.out.println("Example 2");
		numbers[0] = 10;
		numbers[1] = 20;
		numbers[2] = 30;
		System.out.println(numbers[0]);
		System.out.println(numbers[1]);
		System.out.println(numbers[2]);
		
		//We can create an array and insert values like this.
		//The for loop does the same as above. It loops through
		//the array and prints out all of the indexes
		System.out.println("Example 3");
		int[] numbers2 = {5, 6, 7};
		
		for(int i=0; i<numbers2.length; i++) { //The .length is a property
			System.out.println(numbers2[i]);
		}
		//Second way to go though an array and print it out.
		System.out.println("Example 3.2");
		for(int i : numbers2) {
			System.out.print(i + ",");
		}
		System.out.println("\n");
		//This loop goes through the list and prints out all its
		//elements in reverse order
		System.out.println("Example 4");
		for(int i=numbers2.length -1; i>=0; i--) {
			System.out.println(numbers2[i]);
		}
	}

}
