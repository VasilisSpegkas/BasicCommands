
public class Continue {

	public static void main(String[] args) {
		//int numbers[] = new int[5];  //Will create an array with 5 index positions (starting from 0 and ending at 4)
		int [] numbers = {10,20,30,40,50};
		
		//Continues the loop and when the "if condition" is met 
		//it "does something" and then continues the for loop.
		//We can leave the line after the "if condition" empty
		//and it wont do anything
		for(int x : numbers) {
			if(x==30) {
				//System.out.println("Do something");
				System.out.println("skipped " + x);
				continue;
			}
			System.out.print(x);
			System.out.print("\n");
		}
	}

}
