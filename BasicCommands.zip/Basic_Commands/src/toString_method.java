
class FrogsInfo {
	
	private int id;
	private String name;
	
	public FrogsInfo(int id, String name) {
		this.id = id;
		this.name = name;
	}
	
	//The "toString Method" creates a string representation
	//of your object that allows you to identify that object
	//(very helpful for debugging)
	public String toString() {
		//First way to return values (String.format)
		//return String.format("%d: %s", id, name);
		
		//Second way to return values (StringBuilder)
		//Most efficient!!
		StringBuilder sb = new StringBuilder();
		sb.append(id).append(": ").append(name);
		return sb.toString();
		
		//Third way to return values
		//return id + ": " + name;
		/*The same as the above but inefficient because
		//every time we use the "+" sign, we  create a new
		//string and then java concatenates all those 
		//newly created strings and that takes up a lot of
		resources
		*/
	}
}

public class toString_method {

	public static void main(String[] args) {
		FrogsInfo frog1 = new FrogsInfo(7, "Freddy");
		FrogsInfo frog2 = new FrogsInfo(5, "Rogger");
		
		System.out.println(frog1);
		System.out.println(frog2);
		
	}

}
