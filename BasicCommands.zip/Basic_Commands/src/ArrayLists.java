import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ArrayLists {
		
	public static void main(String[] args) {
	
	//ArrayLists are EXPANDABLE!!
	//ArrayList is a JAVA framework
		
		//We type 'Integer' because the it doesn't take in primitive types.
		//We can add the size of our list inside the parenthesis '()'
		ArrayList<Integer> numbers = new ArrayList<Integer>();
		numbers.add(10);
		numbers.add(5);
		numbers.add(100);
		
		System.out.println("First way to iterate.");
		//.get(index) gets us the value inside the index
		System.out.println("Number in index position 1 is: " + numbers.get(1));
		
		//We can iterate through a list using a for loop and the .get() method
		System.out.println("Second way to iterate.");
		for (int i = 0; i < numbers.size(); i++) {
			System.out.println(numbers.get(i));
		}
		//Using the enhanced for loop to iterate
		System.out.println("Third way to iterate.");
		for(Integer index: numbers) {
			System.out.println(index);
		}
		
		//To remove values from an ArrayList
		numbers.remove(numbers.size() - 1);  //Removes last index
		numbers.remove(0);  //Removes first index
		
		//When removing values from an ArrayList its good to know that the items closer to the end
		//of the list will be removed 'faster' than the ones near the start. This happens because
		//when the ArrayList removes values from its start it has to copy all the remainder values 
		//one 'index' back and when it removes for example the last index it only has to 'shrink down'
		//its size.
		
		//Sorting an ArrayList alphabetically
		System.out.println("Sorting list alphabetically.");
		List<String> animals = new ArrayList<String>();
		animals.add("tiger");
		animals.add("lion");
		animals.add("cat");
		animals.add("snake");
		animals.add("mongoose");
		animals.add("elephant");
		Collections.sort(animals);
		for (String index : animals) {
			System.out.println(index);
		}
		
		//We can create a copy of the 'animals' ArrayList like so
		ArrayList<String> copyOfAnimals = new ArrayList<String>(animals);
		for (String index : copyOfAnimals) {
			System.out.println("copyOfAnimals: " + index);
		}
		
		//Sorting an ArrayList by ascending order
		System.out.println("Sorting list numerically by ascending order.");
		List<Integer> numberList = new ArrayList<Integer>();
		numberList.add(3);
		numberList.add(6);
		numberList.add(36);
		numberList.add(72);
		numberList.add(1);
		Collections.sort(numberList);
		for (int index : numberList) {
			System.out.println(index);
		}
		
		//Using the Comparator interface
		System.out.println("Sorting list by length of String.");
		Collections.sort(animals, new StringLengthComparator());
		for (String index : animals) {
			System.out.println(index);
		}
		System.out.println("Sorting list REVERSE alphabetically.");
		Collections.sort(animals, new ReverseAlphabeticalComparator());
		for (String index : animals) {
			System.out.println(index);
		}
		System.out.println("Sorting list REVERSE numerically.");
		//Same as creating the ReverseNumericalComparator class bellow.
		//Watch out for the ');' sign at the end.
		Collections.sort(numberList, new Comparator<Integer>() {
			public int compare(Integer num1, Integer num2) {
				return -num1.compareTo(num2);
			}
		});
		for (int index : numberList) {
			System.out.println(index);
		}
		
		//Sorting a list of type class myPerson by ID
		System.out.println("Sorting data of Class type myPerson by ID");
		List<myPerson> people = new ArrayList<myPerson>();
		people.add(new myPerson(1, "Joe"));
		people.add(new myPerson(3, "Bob"));
		people.add(new myPerson(4, "Clare"));
		people.add(new myPerson(2, "Sue"));
		Collections.sort(people, new Comparator<myPerson>() {
			public int compare(myPerson p1, myPerson p2) {
				if (p1.getId() > p2.getId()) {
					return 1;
				}
				else if(p1.getId() < p2.getId()) {
					return -1;
				}
				return 0;
			}
		});
		for(myPerson person : people) {
			System.out.println(person);
		}
		System.out.println("Sorting data of Class type myPerson by Name");
		//Sorting a list of type class myPerson by Name
		Collections.sort(people, new Comparator<myPerson>() {
			public int compare(myPerson p1, myPerson p2) {
				return p1.getName().compareTo(p2.getName());
			}
		});
		for(myPerson person : people) {
			System.out.println(person);
		}
	}
}

//To use the 'Comparator' method we must create a new class and implement 
//the 'Comparator' interface.
//This Comparator class will sort a list by the length of its Strings
//						...implements Comparator<the type of data i want to compare>
class StringLengthComparator implements Comparator<String> {
	//if o1 == o2 returns 0
	//if o1 > o2 returns 1
	//if o1 < o2 returns -1
	@Override
	public int compare(String o1, String o2) {
		int len1 = o1.length();
		int len2 = o2.length();
		if (len1 > len2) {
			return 1;
		}
		else if(len1 < len2) {
			return -1;
		}
		return 0;
	}
}

class ReverseAlphabeticalComparator implements Comparator<String> {
	@Override
	public int compare(String o1, String o2) {
		return -o1.compareTo(o2); //The negative sign before 'o1' reverses the sort
	}
}

/*class ReverseNumericalComparator implements Comparator<Integer> {
	@Override
	public int compare(Integer o1, Integer o2) {
		return -o1.compareTo(o2); //The negative sign before 'o1' reverses the sort
	}
}*/

class myPerson {
	private int id;
	private String name;
	
	public myPerson(int id, String name) {
		this.id = id;
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return id + ": " + name;
	}
}

