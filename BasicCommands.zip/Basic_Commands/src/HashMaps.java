import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class HashMaps {

	public static void main(String[] args) {

		//HashMaps do not have a specific order in which they store data..
		//(Eventhough it might seem they do...)
		HashMap<Integer, String> map = new HashMap<Integer, String>();
		//To insert 'keys' and 'values' you use put
		map.put(5, "Five");  //'key' = 5, 'value' = "Five"
		map.put(8, "Eight");
		map.put(6,  "Six");
		map.put(4, "Four");
		map.put(2, "Two");
		
		//.get(key) to print out its 'value'
		String text = map.get(4);
		System.out.println(text);
		
		//If you try to retrieve a 'key' that doesnt exist you will get 'null'
		System.out.println(map.get(1));
		
		//You can change the 'value' of a 'key'
		map.put(6, "Hello");
		System.out.println(map.get(6));
		//You CANNOT change the 'key' using the same way
		//for example map.put(3, "Four");
		
		//Iterate though a 'HashMap'
		//'entry' is a variable of type Map.Entry<Integer, String>
		for (Map.Entry<Integer, String> entry: map.entrySet()) {
			int key = entry.getKey();
			String value = entry.getValue();
			System.out.println(key + ": " + value);
		}
		
	}

}
