class Machine {
	private String name;
	private int code;
	
	//IMPORTANT!! When creating a constructor 
	//1.its name MUST be the same as the name of the class 
	//2.and it doesn't have a return type like a method has
	public Machine() {
		//We can use "this" to call a constructor inside a 
		//constructor. 
		//IMPORTANT!! "this" must always be the first line
		//inside the constructor we want to use it.
		//The code bellow will call the third constructor.
		this("Bill", 7);
		System.out.println("Constructor running");		
		//This is where we can set the default value of the
		//instance variable inside our class
		name = "Arnie";
		code = 0;
	}
	//To run this constructor we need to call it by passing
	//in a string parameter when we create a new object later
	public Machine(String name) {
		//We call the third constructor using "this"
		this(name,7);
		System.out.println("Second constructor running");
		this.name = name;
	}
	
	//To run this constructor we need to call it by passing
	//in both a string and an integer parameter when we create a new object
	public Machine(String name, int code) {
		System.out.println("Third constructor running");
		this.name = name;
		this.code = code;
	}
}
public class Constructor {

	public static void main(String[] args) {
		//Create a new "Machine object" and run first constructor
		Machine machine1 = new Machine();
		//Alternate way to create a new "Machine object"
		new Machine();
		
		//Create a new "Machine object" and run second constructor
		Machine machine2 = new Machine("Bertie");
		
		//Create a new "Machine object" and run third constructor
		Machine machine3 = new Machine("Chalky", 7);
		
	}

}
