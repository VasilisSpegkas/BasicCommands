import java.util.Scanner;

public class Switch_01 {

	public static void main(String[] args) {
		
		//We use the switch command to tell java to do
		//a specific task when a specific case appears
		Scanner input = new Scanner(System.in);
		
		System.out.println("Please enter a command: ");
		String text = input.nextLine();
		
		//When the user enters the string "start" the
		//"Machine started!" text will be printed
		switch(text) {
		case "start":
			System.out.println("Machine started!");
			break;
		
		//When the user enters the string "stop" the
		//"Machine stopped." text will be printed
		case "stop":
			System.out.println("Machine stopped.");
			break;
		
		//If none of the above cases is true then the 
		//default case will be activated and "Command not
		//recognized" will be printed.
		default:
			System.out.println("Command not recognized");
		}
	}

}
