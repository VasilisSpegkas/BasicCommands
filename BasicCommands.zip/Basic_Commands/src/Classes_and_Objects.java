//Classes can contain
//1.Data
//2.Methods (Subroutines)
class Person {
	//We enter our Instance variables (data or "state")
	String name;
	int age;
	
	//We create the "speak" and the "sayHello" methods
	void speak() {
		for(int i=0; i<3; i++) {
		System.out.println("My name is: " + name + " and I am " + age + " years old");
		}
	}
	void sayHello() {
		System.out.println("Hello there!");
	}
}

public class Classes_and_Objects {

	public static void main(String[] args) {
		
		//Using the "Person" class we create a new object  
		//of type "Person()" and we name it "person1" which is a variable 
		Person person1 = new Person();
		Person person2 = new Person();
		
		//We use our "Instance variables" and our "methods"
		person1.name = "John Papadopoulos";
		person1.age = 18;
		person1.speak();
		person1.sayHello();
				
		person2.name = "Maria Karagianni";
		person2.age = 29;
		person2.speak();
		person2.sayHello();
		}

}
