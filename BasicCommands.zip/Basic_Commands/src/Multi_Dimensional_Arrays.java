
public class Multi_Dimensional_Arrays {

	public static void main(String[] args) {
		
		//Will print out index number 2 from the "values" array
		int[] values = {3, 5, 2343};
		System.out.println(values[2]);
		
		//By using two sets of brackets [][] 
		//we create a two-dimensional array
		int[][] grid = {
				{3, 5, 2343},
				{2, 4},
				{1, 2, 3, 4}
		};
		//This will print out the second number from the
		//second index.
		System.out.println(grid[1][1]);
		//This will print out the third number from the 
		//first index
		System.out.println(grid[0][2]);
		
		//This specific "for_loop" will loop inside the "grid"
		//array like it was a table on excel and will print
		//out each value starting from the first row and moving
		//to the next collumn
			for(int row=0; row<grid.length; row++) {
				for(int col=0; col < grid[row].length; col++) {
					//By removing "ln" after print it wont print
					//each result on a different line. Also by
					//adding "\t" we tell java to enter the "tab"
					//character after each result.
					System.out.print(grid[row][col] + "\t");
				}
				//We enter a new line after the second loop ends
				//to print out our results looking like a table
				System.out.println();
			}
			
		//We create a two-dimensional array and assign it
		//with 2 and 3 number of indexes respectively
		String[][] texts = new String[2][3];
		texts[0][1] = "Hello there..";
		texts[0][2] = "General Kenoby!";
		//The first two prints will print out the given
		//text above. The last one will print the default
		//value given by java which is null.
		System.out.println(texts[0][1]);
		System.out.println(texts[0][2]);
		System.out.println(texts[0][0]);
		
		//We can create a two-dimensional array without 
		//specifying the number of "columns".So by
		//default this will print out null
		String[][] words = new String[2][];
		System.out.println(words[0]);
		//We can then manually enter the number of indexes 
		//for our columns and enter a value for a specific
		//index we want and print it.
		words[0] = new String[3]; 
		words[0][1] = "hi there";
		System.out.println(words[0][1]);
		
	}

}
