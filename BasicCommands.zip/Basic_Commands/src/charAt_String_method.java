
public class charAt_String_method {

	public static void main(String[] args) {
		String sentence = "This is a cat";
		char letter = sentence.charAt(0);
		System.out.println(letter);
	}

}
