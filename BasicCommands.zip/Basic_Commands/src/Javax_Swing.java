import javax.swing.JOptionPane;

public class Javax_Swing {

	public static void main(String[] args) {
		
		JOptionPane.showMessageDialog(null, "This is a message");
		
		String n = JOptionPane.showInputDialog("Enter your input");
	
		System.out.println(n);
	}

}
