
public class IF_Condition {

	public static void main(String[] args) {
	
		//Will print out either "True" or "False" depending on the condition
		boolean cond = 5 != 5;	{			
		System.out.println(cond);
		}
		
		//When "if" condition is true will print out the string. If not it does nothing
		if(4 == 4) {
			System.out.println("Yes, it's true");
		}
		
		//Using the "else if" and "else" condition
		int myGrade = 15;
		String goodPractice = "Something";
		if(myGrade < 10) {
			System.out.println("Fail");
		}
		else if(myGrade > 16) {
			System.out.println("Pass with honours");
		}
		else {
			System.out.println("Pass");
		}
		//ITS GOOD PRACTICE TO USE != null FOR STRINGS SO WE DONT GET NullPointerException
		if ((goodPractice != null) && (myGrade > 16)) {
			System.out.println("Pass with good practice!");
		}
		
		//Using the "break" command to get out of a loop
		int loop = 0;
		
		while(true) {
			System.out.println("Looping: " + loop);
			
			if(loop == 5) {
				break;
			}
			
			loop++;
			
			System.out.println("Running");
		}
	}
	

}
