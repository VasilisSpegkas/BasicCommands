public class For_loop {
	public static void main(String[] args) {
		
		//FOR LOOP SYNTAX 
		//for (Starting point ; Condition ; Step)
		
		//Prints out "Hello" and the value of "i" until "i=5"
		//the "++" basically translates to "i = i + 1"
		System.out.println("First FOR LOOP");
		for(int i=0; i < 5; i++)  {
			System.out.println("The value of i is: " + i);
		}
		
		//ENCHANCED FOR LOOP ** Mostly used to parse through a list
		//SYNTAX for (myVariable : mylist)
		String[] mylist = {"Hello", "world"};
		System.out.println("Enchanced for loop results ");
		for (String hello : mylist) {
			 System.out.println(hello);
		}
		
		//Prints out the value of i using the format specifier "%" and also
		//adds a new line each time using "/n"
		System.out.println("For loop example with format specifier");
		for(int i=0; i < 5; i++) {
			System.out.printf("The value of i is: %d\n", i);
		}
		System.out.println("\n");
		//We can initialize the value of x but change its values at the start of a for loop
		System.out.println("Last for loop example");
		int x = 5;  	//Initialize x as 5
		for(x=10; x < 20; x++) { 	//Change its value inside the for loop to 10
			System.out.println("The value of x is: " + x);
		}
		//Stores the value of x even after the for loop is complete
		System.out.println(x);
	}
}
