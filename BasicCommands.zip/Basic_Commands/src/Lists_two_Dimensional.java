import java.util.Scanner;

public class Lists_two_Dimensional {

	public static void main(String[] args) {
		
		Scanner input =  new Scanner(System.in);
		System.out.println("Enter the dimensions of your list: ");
		System.out.println("Rows: ");
		int x = input.nextInt();
		System.out.println("Columns: ");
		int y = input.nextInt();
		
		int[][] mylist = new int[x][y];
		
		System.out.println(mylist.length); //The number of rows
		System.out.println(mylist[0].length); //The number of columns
		
		for (int row = 0; row < mylist.length; row++) {
			System.out.println("\n");
			for (int col = 0; col < mylist[0].length; col++) {
				System.out.print(mylist[row][col] + "|");
			}
		}
	}

}
