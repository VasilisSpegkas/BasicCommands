class Robot {
	public void speak(String text) {
		System.out.println(text);
	}
	
	public void jump(int height) {
		System.out.println("Will jump " + height + " meters");
	}
	
	//We can declare two arguments inside a void method
	public void move(String direction, int meters) {
		System.out.println("Moving " + meters + " meters. Direction is " + direction);
	}
	
}
public class Method_Parameters {

	public static void main(String[] args) {
		//We create a new object with our class and
		//use the void methods we created on it
		Robot Sam = new Robot();
		Sam.speak("Hi i am Sam");
		Sam.jump(7);
		Sam.move("North",5);
		
		//We can also create a new argument and use it
		//for our void method afterwards
		String greeting = "Hello there!";
		int value = 10;
		Sam.speak(greeting);
		Sam.move("West", value);
		
	}

}
