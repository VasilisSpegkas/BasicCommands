public class Strings_and_Combinations {
	public static void main(String[] args) {
				
		String text = "Hello";
		
		String blank = " ";
		
		String name = "Bob";
		
		String greeting = text + blank + name;
		
		// First way to print out a string
		System.out.println(greeting);
		// Second way to print out the same string
		System.out.println("Hello" + " " + "Bob");
		
		// Combination of different data types
		int myInt = 7;
		System.out.println("My integer is: " + myInt);
	
		
		double myDouble = 7.8;
		System.out.println("My number is: " + myDouble + ".");
	}
}
