class Frog {
	
	//By using the "private" keyword we cannot use the
	//variables outside the frog class
	private String name;
	private int age;
	
	
	//Usual ways of creating "public get methods"
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}	
	
	
	//To create the above "get methods" we need to know the
	//internal variables inside the frog class
	//(in this case "String name;" and "int Age;") and that is
	//undesirable and complex.Instead we choose
	//to create "set methods" which only require that we
	//know the "methods" of the frog class.
	
	//public void setName(String newName) {
		//name = newName;
		//}
	//public void setAge(int newAge){
		//age = newAge;
		//}

	//To access the "private variables" we use .this method
	public void setName(String name) {
		this.name = name;
	}
	public void setAge(int age) {
		this.age = age;
	}

}

public class This_method {

	public static void main(String[] args) {
		
		Frog frog1 = new Frog();
		
		//To access our "public get.methods" we need our variables
		//inside the class to be "public" and we type this
		//frog1.name  = "Bertie";
		//frog1.age = 1;
		//System.out.println(frog1.getName());
		//System.out.println(frog1.getAge());
		
		
		
		//To access our "public void set.methods" we type this
		frog1.setName("Bertie");
		frog1.setAge(1);
		System.out.println(frog1.getName());
		System.out.println(frog1.getAge());
	}

}
