import java.util.Random;

//General syntax --> (int) (Math.random()*range ) + min
public class Random_numbers {

	public static void main(String[] args) {
		
		System.out.println("Math.random results");
		//Math.random on its own just prints out numbers
		//from 0 to 1
		for (int i=0; i<10; i++) {
			System.out.println(Math.random());
		}
		
		System.out.println("First example results");
		//Will create 10 random numbers from 1 to 10.
		for (int i=0; i<10; i++) {
			System.out.println( (int) (Math.random()*10) +1 );
		}
		
		System.out.println("Second example results");
		//Same thing as example 1 but with the use of variables 
		int min = 5;
		int max = 15;
		int range = max-min +1;
		for (int i=0; i<10; i++) {
			System.out.println((int) (Math.random()*range) +min);
		}
		
		System.out.println("Third example results");
		//We can use the Random class to generate numbers.
		//Always **import java.util.Random;** when using this
		//Random generates numbers from 0 to 1
		Random gen = new Random();
		for (int i=0; i<10; i++) {
			//Creates doubles that are multiplied by 10 and start from 1
			System.out.println( gen.nextDouble()*10 +1);
			
			//When using nextInt we need to enter a range number inside the parenthesis
			//or else it will print out random integers from 0 to 2^32.
			//The following creates integers from 0 to 5 starting from 1
			System.out.println( gen.nextInt(5) + 1);
		}
		
	}

}
