
class Thing {
	//Instance variables can have as many copies as we want
	public String name;
	
	//A "static" variable is part of its Class and there
	//is only one copy of it
	public static String description;
	
	//We create a return(void) type method
	public void showName() {
		System.out.println(name);
	}
	
	//We create a static return(void) type method
	public static void showInfo() {
		System.out.println("Hello");
		//Static method can access static data
		System.out.println(description);
		//but static methods cannot access instance variables
		//Won't work --> System.out.println(name);
	}
	
	//Instance methods can access static data
	public void showName2() {
		System.out.println(description + ": " + name);
	}
	
	//We create a constant static variable.
	//IMPORTANT!! we must always give it a specific value
	//that of cource cannot be changed afterwards
	public final static int LUCKY_NUMBER = 7;
	
	//We create a counter for the ".Thing constructor"
	public static int count = 0;
	//We use the counter to pass its value to an instance variable called "id"
	public int id;
	public Thing() {
		count++;
		id = count;
	}
	//We can create a return type method that combines "instance" and "static" data
	//"Object id" --> refers to instance data
	//"description" --> refers to static data
	//"name" --> refers to instance data
	public void showId() {
		System.out.println("Object id " + id + ", " + description + ": " + name);
	}
	
}

public class Static_and_Final {

	public static void main(String[] args) {
		
		//In this case we created two copies of the "name"
		//instance variable
		Thing thing1 = new Thing();
		Thing thing2 = new Thing();
		thing1.name = "Bob";
		thing2.name = "Sue";
		System.out.println(thing1.name);
		System.out.println(thing2.name);
				
		//To access a static variable we use its class name
		Thing.description = "I am a thing";
		System.out.println(Thing.description);
		
		//Same as System.out.println(thing1.name); and
		//System.out.println(thing2.name);
		thing1.showName();
		thing2.showName();
		
		//To access a "static void type method" we call it
		//by its class name
		Thing.showInfo();
		
		//We access static data by using the instance methods
		thing1.showName2();
		thing2.showName2();
		
		//Example of a static value already implement in java
		System.out.println(Math.PI);
		//Our own static constant variable that cannot change
		System.out.println(Thing.LUCKY_NUMBER);
		
		//Prints out how many times we used the "Thing constructor" usign only the count variable
		System.out.println("You used the Thing constructor " + Thing.count + " times.");
		
		//Example of combining instance data and static data using the "id" variable
		thing1.showId();
		thing2.showId();
		
	}

}