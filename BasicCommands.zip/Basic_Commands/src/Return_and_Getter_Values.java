class PersonsInfo {
	String name;
	int age;
	//We can use "void" to get a return value from a method
	void yearsToRetirement() {
		int years = 65 - age;
		System.out.println("You have " + years + " years left till retirement");
	}
	//Same thing as before but by using "return" to get
	//a value
	int yearsToRetire() {
		int yearsLeft = 65 - age;
		return yearsLeft;
	}
	
	//We can "get" values by using getters
	int getAge() {
		return age;
	}
	
	String getName() {
		return name;
	}
}
	
public class Return_and_Getter_Values {

	public static void main(String[] args) {
		PersonsInfo person1 = new PersonsInfo();
		person1.age = 33;
		person1.name = "Bill";
		
		//Void method
		person1.yearsToRetirement();
		
		//Return value method
		int pension = person1.yearsToRetire();
		System.out.println("Years left for pension " + pension);
		
		//Getter method
		int age = person1.getAge();
		String name = person1.getName();
		System.out.println("Name is: " + name);
		System.out.println("Age is: " + age);
		
	}
}
