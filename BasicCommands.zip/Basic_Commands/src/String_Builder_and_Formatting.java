
public class String_Builder_and_Formatting {

	public static void main(String[] args) {
		
		String info = "";
		
		//Inefficient way to create a string because we are 
		//creating a new "info" string each time we assign it
		//with a new value.
		info += "My name is Bod.";
		info += " ";
		info += "I am a builder.";
		System.out.println(info);
		
		//We use the StringBuilder constructor to create a new object
		//called "sb". By using the ".append method" we do not create a
		//new string each time but instead we modify its existing
		//value which is more "efficient".
		StringBuilder sb = new StringBuilder();
		sb.append("My name is Sue.");
		sb.append(" ");
		sb.append("I am a lion tamer.");
		System.out.println(sb.toString());
		
		//A shortcut to the ".append method"
		StringBuilder s = new StringBuilder();
		s.append("My name is Roger.").append(" ")
		.append("I am a skydiver");
		System.out.println(s.toString());
		
		//FORMATTING STRINGS//
		
		//To insert a "tab" we use \t
		//To insert a "new line" we use \n
		//We can use "print" instead of "println" to not add a new line after our print
		System.out.print("Here is some text.\tThat was a tab.\nThat was a new line");
		System.out.println("More text");
		
		//We use "%d" to define the number we want to print inside a string
		System.out.printf("The total cost is %d" + "\n", 5);
		
		//We can use "%d" for multiple numbers separated with a "," after the string
		System.out.printf("The total cost is %d and the quantity is %d" + "\n" , 5, 120);
		
		//We can use "-" and a number defining the number of characters we want to right align
		//our results or just the number to left align our results.  
		System.out.printf("The total cost is %-3d and the quantity is %3d" + "\n", 5, 120);
		
		//Example of right alignment
		for(int i=0; i<5; i++) {
			System.out.printf("%3d: some text here\n", i);
		}
		
		//The %s represents text
		for(int i=0; i<5; i++) {
			System.out.printf("%d: %s\n", i, "here is some text");
		}
		
		//The %f represents "double" value numbers.
		//By default its precision of decimal digits is 6. 
		System.out.printf("Total value: %f\n", 5.6874);
		
		//We can specify the number of decimals that will be printed like this.
		//They will also be rounded up.
		System.out.printf("Total value: %.2f\n", 5.6874);
		
		//We can also use the alignment method like this.
		System.out.printf("Total value: %9.2f\n", 343.23423);
		
		
	}

}
