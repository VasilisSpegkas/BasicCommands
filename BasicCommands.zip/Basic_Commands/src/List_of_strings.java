
public class List_of_strings {

	public static void main(String[] args) {
		
		//We create an array called "words" of data type "String"
		//with 3 indexes
		String[] words = new String[3];
		
		//We assign each index with a value
		words[0] = "Hello";
		words[1] = "to";
		words[2] = "you";
		
		//We print out index number 2
		System.out.println(words[2]);
		
		//We create an array called "fruits" of data type "String"
		//with 4 indexes
		String[] fruits = {"apple", "banana", "pear", "kiwi"};
		
		//We loop through the "fruits" array assigning with each
		//loop an index starting from 0 to a variable called "i"
		//and then printing out "i"
		for(String i: fruits) {
			System.out.println(i);
		}
		
		//We create an array called "texts" with 2 indexes. The
		//default value for String data types assigned by java
		//is "null". So this will print out the default value "null"
		String[] texts = new String[2];
		System.out.println(texts[0]);
						
	}
	

}
