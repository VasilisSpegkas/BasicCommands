import java.util.Scanner;

public class User_input {
	public static void main(String[] args) {
		
		//FIRST INPUT EXAMPLE ** String
		//Create scanner object
		Scanner input = new Scanner(System.in);
		
		//Output the prompt
		System.out.println("Enter a line of text: ");
		
		//Wait for the user to enter a line of text
		String line = input.nextLine();
		
		//Tell them what they entered
		System.out.println("You entered: " + line);
	
		//SECOND INPUT EXAMPLE ** INTEGER
		//Create scanner object
		Scanner input1 = new Scanner(System.in);
					
		//Output the prompt
		System.out.println("Enter an integer: ");
					
		//Wait for the user to enter an integer
		int value = input1.nextInt();
					
		//Tell them what they entered
		System.out.println("You entered: " + value);
		
		//SECOND INPUT EXAMPLE ** INTEGER
		//Create scanner object
		Scanner input2 = new Scanner(System.in);
							
		//Output the prompt
		System.out.println("Enter a double value: ");
							
		//Wait for the user to enter an integer
		double value1 = input2.nextDouble();
							
		//Tell them what they entered
		System.out.println("You entered: " + value1);
	}
}

