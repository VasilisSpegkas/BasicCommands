import java.util.Arrays;
import java.util.Scanner;

import javax.swing.JPasswordField;

public class PasswordEncryption {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter you password");
		
		JPasswordField passwordField = new JPasswordField(10);
		passwordField.setText(input.next());
		passwordField.setEchoChar('*');
		passwordField.getEchoChar();
		char[] password = passwordField.getPassword();
		
		char[] correctPass = new char[] {'s', 'e', 'c', 'r', 'e', 't'};
		 
		if (Arrays.equals(password, correctPass)) {
		    System.out.println("Password is correct");
		} else {
		    System.out.println("Incorrect password");
		}
		
	}
}
